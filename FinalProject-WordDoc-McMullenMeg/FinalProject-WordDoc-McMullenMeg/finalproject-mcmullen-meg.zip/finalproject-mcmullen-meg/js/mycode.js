// var div = document.getElementById('main');
// var display = 0;

// function hideShow()
// {
//    if(display == 1)
//     {
//        div.style.display = 'block';
//         display = 0;
//     }
//     else
//     {
//        div.style.display = 'none';
//        display = 1;
//     }
// }

function showSkills() {
    var x = document.getElementById("skills");
    x.style.display = "block";
    x = document.getElementById("languages");
    x.style.display = "none";
    x = document.getElementById("tools");
    x.style.display = "none";
  }

  function showLanguages() {
    var x = document.getElementById("languages");
    x.style.display = "block";
    x = document.getElementById("skills");
    x.style.display = "none";
    x = document.getElementById("tools");
    x.style.display = "none";
  }

  function showTools() {
    var x = document.getElementById("tools");
    x.style.display = "block";
    x = document.getElementById("skills");
    x.style.display = "none";
    x = document.getElementById("languages");
    x.style.display = "none";
    
  }